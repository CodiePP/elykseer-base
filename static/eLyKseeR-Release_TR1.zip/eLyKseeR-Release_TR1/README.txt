eLyKseeR technical review release 1
===================================

origins:

* https://github.com/CodiePP/elykseer-base
* https://github.com/CodiePP/elykseer-cli
* https://github.com/CodiePP/prngsharp
* https://github.com/CodiePP/openssl-net

This is a first release of eLyKseeR intended for technical review.

!! DO NOT USE THIS SOFTWARE FOR PRODUCTION USE !!
!! N'UTILISEZ PAS CE LOGICIEL POUR QC DE VRAI !!
!! DIESE SOFTWARE SOLLTE NICHT BENUTZT WERDEN !!

This release's only purpose is to evaluate the software's capabilities on the target platforms "Linux" and "Windows".

The software will cease to function on SEP-16.
We will hopefully have a new version ready by then.

We highly appreciate your feedback: feedback@elykseer.com
or open an issue on https://github.com/CodiePP/elykseer-base/issues

Thank you for showing interest in our software.

