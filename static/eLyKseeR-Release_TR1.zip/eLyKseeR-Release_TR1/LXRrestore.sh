#!/bin/sh

set -e

basen=`basename $0`
basep=`dirname $0`
LXRRELEASE="Release_TR1"
LXRPLATFRM=`uname -s`
LXRPROG=${basen%.sh}

SCR=${basep}/${LXRRELEASE}/Mono/${LXRPROG}.${LXRPLATFRM}.sh

if [ -x ${SCR} ]; then
  ${SCR} $*
  exit 1
else
  echo "Start script $0 not found!"
  exit 1
fi

