#!/bin/sh

set -e

LXRRELEASE="Release_TR1"
LXRPLATFRM="Linux"

if [ -d ${LXRRELEASE}/${LXRPLATFRM} ]; then 
	cd ${LXRRELEASE}/${LXRPLATFRM}
	./LXRrestore.${LXRPLATFRM}.exe $*
else
	echo "Not found!"
fi

