#!/bin/sh

set -e

basep=`dirname $0`

export DYLD_LIBRARY_PATH=${basep}

mono --arch=64 ${basep}/LXRbackup.Mono.exe $*

