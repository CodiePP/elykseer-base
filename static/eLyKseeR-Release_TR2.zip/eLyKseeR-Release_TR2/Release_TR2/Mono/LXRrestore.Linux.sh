#!/bin/sh

set -e

basep=`dirname $0`

export LD_LIBRARY_PATH=${basep}

mono ${basep}/LXRrestore.Mono.exe $*

